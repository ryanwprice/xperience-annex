The www folder is where all of your HTML, CSS, and Images should go for the recipe assignment. This is also the folder you need to ZIP up and submit for grading.

The Recipe folder (AKA the folder this README.txt file is in) is where you can keep all of your working files. Example: PSDs, stock images, notes, etc.

The index.html and style.css files have some default content created for you, specifically the meta tags and the #wrapper div.

Meta tags:

You must edit these appropriately for your recipe. If you are unsure of what is required, please ask your instructor.

#wrapper div:
This is a simple layout element that will center your content and make it fit a width of 600px. You can adjust the width or delete it completely, it's up to you. It is merely meant as a jumping off point. Feel free to adapt it in any way you see fit!